XR CAREER GUIDE ANDROID PROJECT

This is a native Android WebView wrapper for https://xrndh.netlify.app/.
It is source code, not a compiled APK yet.

BUILD APK USING GITHUB ACTIONS (Android phone friendly):
1. Create a new repository on GitHub.
2. Upload the CONTENTS of this folder to the repository root.
3. Open the repository's Actions tab.
4. Select "Build XR Career Guide APK" and tap Run workflow (or push to main).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, find Artifacts, and download XR-Career-Guide-debug-APK.
7. Extract the downloaded artifact ZIP to get app-debug.apk.
8. Transfer/open app-debug.apk on Android and allow installation from that source if Android asks.

TESTING NOTES:
- The workflow runs a basic unit smoke test and compiles a debug APK.
- This environment does not have Android SDK/build tools, so the APK has not been compiled or device-tested here.
- The app loads the live Netlify website and therefore needs internet to display current site content.
- A debug APK is for testing. A Play Store release needs a signed release build and further testing.
