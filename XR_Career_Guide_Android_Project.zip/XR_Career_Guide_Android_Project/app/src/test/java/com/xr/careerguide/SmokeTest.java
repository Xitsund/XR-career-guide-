package com.xr.careerguide;

import org.junit.Test;
import static org.junit.Assert.*;

public class SmokeTest {
    @Test
    public void appIdentityIsConfigured() {
        assertEquals("XR Career Guide", "XR Career Guide");
        assertTrue("Home URL should use HTTPS", "https://xrndh.netlify.app/".startsWith("https://"));
    }
}
